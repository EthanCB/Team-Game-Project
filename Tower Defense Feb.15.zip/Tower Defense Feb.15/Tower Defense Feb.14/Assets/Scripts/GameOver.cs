using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Mono.Data.Sqlite;
using System.Data;
using System;
using System.Data.SqlClient;
using System.IO;

public class GameOver : MonoBehaviour {

	public string menuSceneName = "Node";
    public Text username;
    public Text score;
    public Text highScore;

    private void Start()
    {
        string inUsername = username.text.ToString();
        string inScore = score.text.ToString();

        //string _constr = "URI=file:" + Application.dataPath + "/StreamingAssets/GameScores.db";
        string filepath = Application.dataPath + "/StreamingAssets/GameScores.db";
        if (!File.Exists(filepath))
        {
            Debug.LogWarning("Arquive \"" + filepath + "\" doenst exist. tring to create from \"" + filepath);
            WWW loadDB = new WWW("jar:file://" + filepath);
            while (!loadDB.isDone) { }
            // then save to Application.persistentDataPath
            File.WriteAllBytes(filepath, loadDB.bytes);
        }
        string connection = "URI=file:" + filepath;
        Debug.Log("Stabilishing connection to: " + connection);
        IDbConnection _dbc;
        IDbCommand _dbcm;
        IDataReader _dbr;

        _dbc = new SqliteConnection(connection);
        _dbc.Open();
        _dbcm = _dbc.CreateCommand();


        _dbcm.CommandText = "SELECT `PlayerID`, `PlayerName`, `PlayerScore` FROM `PlayerScore` ORDER BY `PlayerScore` desc LIMIT 5";
        _dbr = _dbcm.ExecuteReader();
        while (_dbr.Read())
        {
            int id = _dbr.GetInt32(0);
            string name = _dbr.GetString(1);
            int theScore = _dbr.GetInt32(2);

            highScore.text = highScore.text + "\n" + name + " : " + theScore;
            Debug.Log(name + ":" + theScore);
        }
        _dbr.Close();
        _dbr = null;
        _dbcm.Dispose();
        _dbcm = null;
        _dbc.Close();
        _dbc = null;
    }
    public SceneFader sceneFader;

	public void Retry ()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

	public void Menu ()
	{
        //Debug.Log(username.text);
        //sceneFader.FadeTo(menuSceneName);
        if (username.text == "")
        {
            Debug.Log("username required");
        }
        else
        {
            string inUsername = username.text.ToString();
            string inScore = score.text.ToString();

            //string _constr = "URI=file:" + Application.dataPath + "/StreamingAssets/GameScores.db";
            string filepath = Application.dataPath + "/StreamingAssets/GameScores.db";
            if (!File.Exists(filepath))
            {
                Debug.LogWarning("Arquive \"" + filepath + "\" doenst exist. tring to create from \"" + filepath);
                WWW loadDB = new WWW("jar:file://" + filepath);
                while (!loadDB.isDone) { }
                // then save to Application.persistentDataPath
                File.WriteAllBytes(filepath, loadDB.bytes);
            }
            string connection = "URI=file:" + filepath;
            Debug.Log("Stabilishing connection to: " + connection);
            IDbConnection _dbc;
            IDbCommand _dbcm;
            IDataReader _dbr;
            //string sqlInsert = "INSERT INTO `PlayerScore` (`PlayerID`, `PlayerName`, `PlayerScore`) " +
            //    "VALUES (NULL, @playerName, @playerScore)";

            //SqliteCommand command = new SqliteCommand();

            //_dbcm.Parameters.Add(new SqliteParameter("@playerName", inUsername));
            //_dbcm.Parameters.Add(new SqliteParameter("@playerScore", inScore));

            //_dbcm.CommandText = sqlInsert;
            ////command.ExecuteNonQuery();
            //IDataReader reader = _dbcm.ExecuteReader();

            //- This is _dbc
            //IDbConnection dbconn;
            //- This is conneciton
            //string conn = "URI=file:" + Application.dataPath + "/lift_DB.s3db";         //Path to database.
            //- This is _dbcm
            //IDbCommand dbcmd = dbconn.CreateCommand();  


            //Insert Statement
            _dbc = new SqliteConnection(connection);
            _dbc.Open();
            _dbcm = _dbc.CreateCommand();                                                            

            string sqlInsert = "INSERT INTO `PlayerScore` (`PlayerID`, `PlayerName`, `PlayerScore`) " +
                "VALUES (NULL, @playerName, @playerScore)";

            //SqliteCommand command = new SqliteCommand();                                
            _dbcm.Parameters.Add(new SqliteParameter("@playerName", inUsername));
            _dbcm.Parameters.Add(new SqliteParameter("@playerScore", inScore));

            _dbcm.CommandText = sqlInsert;                                              
            //command.ExecuteNonQuery();
            
            IDataReader reader = _dbcm.ExecuteReader();
            while (reader.Read())
            {
            }
            reader.Close();                                                             //closes reader ----- not sure if this is need since im not reading from a database only writing to
            reader = null;
            _dbcm.Dispose();                                                            //disposes of command
            _dbcm = null;
            _dbc.Close();                                                             //closes connection to database
            _dbc = null;


            //Select Statement
            _dbc = new SqliteConnection(connection);
            _dbc.Open();
            _dbcm = _dbc.CreateCommand();


            _dbcm.CommandText = "SELECT `PlayerID`, `PlayerName`, `PlayerScore` FROM `PlayerScore` ORDER BY `PlayerScore` desc LIMIT 5";
            _dbr = _dbcm.ExecuteReader();

            highScore.text = "Top 5 Players:";
            while (_dbr.Read())
            {
                int id = _dbr.GetInt32(0);
                string name = _dbr.GetString(1);
                int theScore = _dbr.GetInt32(2);

                
                highScore.text = highScore.text + "\n" + name + " : " + theScore;
                Debug.Log(name + ":" + theScore + "\n");
            }
            _dbr.Close();
            _dbr = null;
            _dbcm.Dispose();
            _dbcm = null;
            _dbc.Close();
            _dbc = null;
        }
    }
}


//string conn = "URI=file:" + Application.dataPath + "/GameScores.db";
//IDbConnection dbconn;
//dbconn = (IDbConnection)new SqliteConnection(conn);
//using (IDbConnection dbConnection = new SqliteConnection(conn))
//{
//    dbConnection.Open();
//    using (IDbCommand dbCmd = dbConnection.CreateCommand())
//    {
//        string sqlQuery = "SELECT PlayerID, PlayerName, PlayerScore FROM PlayerScore";
//        dbCmd.CommandText = sqlQuery;
//        using (IDataReader reader = dbCmd.ExecuteReader())
//        {

//            dbConnection.Close();
//            reader.Close();
//        }
//    }
//}
//dbconn.Open();
//IDbCommand dbcmd = dbconn.CreateCommand();
//string sqlQuery = "SELECT PlayerID, PlayerName, PlayerScore FROM PlayerScore";
//dbcmd.CommandText = sqlQuery;
//SqlDataReader reader;
//reader = dbcmd.ExecuteReader();
//while (reader.Read())
//{
//    int id = reader.GetInt32(0);
//    string name = reader.GetString(1);
//    int theScore = reader.GetInt32(2);

//    Debug.Log("id = " + id + "  username =" + name + "  score =" + theScore);
//}
//reader.Close();
//reader = null;
//dbcmd.Dispose();
//dbcmd = null;
//dbconn.Close();
//dbconn = null;


            

    /*Debug.Log(username.text + " " + score.text);
    SceneManager.LoadScene(SceneManager.GetActiveScene().name);*/

