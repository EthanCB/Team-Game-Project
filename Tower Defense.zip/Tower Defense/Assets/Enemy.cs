﻿using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour {

    public float startSpeed = 10f;
    public float speed;

    public float startHealth = 100;
    private float health;

    private Transform target;
    private int wavePointIndex = 0;

    [Header("Unity Stuff")]
    public Image healthBar;

    private void Start()
    {
        speed = startSpeed;
        health = startHealth;
        target = Waypoints.waypoints[0];

    }

    private void Update()
    {
        Vector3 dir = target.position - transform.position;
        transform.rotation = Quaternion.LookRotation(-dir);
        transform.Translate(dir.normalized * speed * Time.deltaTime, Space.World);

        if(Vector3.Distance(transform.position, target.position) <= 0.4f)
        {
            GetNextWaypoint();
        }        
    }

    void GetNextWaypoint()
    {
        if(wavePointIndex >= (Waypoints.waypoints.Length - 1))
        {
            Destroy(gameObject);
            return;
        }
        wavePointIndex++;
        target = Waypoints.waypoints[wavePointIndex];
    }

    public void TakeDamage (float amount)
    {
        health -= amount;

        healthBar.fillAmount = health / startHealth;

        /*if (health <= 0)
        {
            Die();
        }*/
    }

    void Die()
    {
        //PlayerStats.Money += worth;

        //GameObject effect = (GameObject)Instantiate(deathEffect, transform.position)

        //Destroy(effect, 5f);

        WaveSpawner.enemiesAlive--;

        Destroy(gameObject);
    }
}
