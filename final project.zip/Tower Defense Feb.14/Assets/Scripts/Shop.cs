using UnityEngine;

public class Shop : MonoBehaviour {

	BuildManager buildManager;

	void Start ()
	{
		buildManager = BuildManager.instance;
	}

	public void SelectStandardTurret ()
	{
		Debug.Log("Standard Turret Selected");
		buildManager.SetTurretToBuild(buildManager.standardTurretPrefab);
	}

	public void SelectMissileLauncher()
	{
		Debug.Log("Missile Launcher Selected");
		buildManager.SetTurretToBuild(buildManager.missileTurretPrefab);
	}
    
	public void SelectLaserBeamer()
	{
		Debug.Log("Laser Beamer Selected");
		buildManager.SetTurretToBuild(buildManager.laserTurretPrefab);
	}

}
